package page;

import com.epam.healenium.annotation.DisableHealing;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.text.Normalizer;

public class FormPage {
    private final WebDriver driver;

    private final By FIRST_NAME_TEXT_BOX = By.id("first-name");
    private final By LAST_NAME_TEXT_BOX = By.id("last-name");
    private final By JOB_TITLE = By.id("job-title");

    private final By rdBtn_highSchool = By.id("radio-button-1");
    private final By rdBtn_college = By.id("radio-button-3");
    private final By rdBtn_gradeSchool = By.id("radio-button-3");

    private final By chkBox_Male = By.id("checkbox-1");
    private final By chkBox_female = By.id("checkbox-2");
    private final By chkBox_preferNotToSay = By.id("checkbox-3");

    @FindBy(id = "select-menu")
    private WebElement list_yearsOfExp;

    private final By date = By.id("datepicker");

    private final By btn_submit = By.cssSelector(".btn-primary");

    public FormPage(WebDriver driver) {
        PageFactory.initElements(driver, this);
        this.driver = driver;
    }

    public FormPage inputFirstName(String firstName) {
        driver.findElement(FIRST_NAME_TEXT_BOX).sendKeys(firstName);
        return this;
    }

    public FormPage inputLastName(String lastName) {
        driver.findElement(LAST_NAME_TEXT_BOX).sendKeys(lastName);
        return this;
    }

    public FormPage inputjobTitle(String jobTitle) {
        driver.findElement(JOB_TITLE).sendKeys(jobTitle);
        return this;
    }

    public FormPage selectEductionHighSchool() {
        driver.findElement(rdBtn_highSchool).click();
        return this;
    }

    public FormPage selectEducationCollege() {
        driver.findElement(rdBtn_college).click();
        return this;
    }

    public FormPage selectEduction() {
        driver.findElement(rdBtn_gradeSchool).click();
        return this;
    }

    public FormPage selectGenderMale() {
        driver.findElement(chkBox_Male).click();
        return this;
    }

    public FormPage selectGenderFemale() {
        driver.findElement(chkBox_female).click();
        return this;
    }

    public FormPage selectPreferNotToSay() {
        driver.findElement(chkBox_preferNotToSay).click();
        return this;
    }

    @DisableHealing
    public FormPage selectExperience(String exp) {
        Select select = new Select(list_yearsOfExp);
        select.selectByVisibleText(exp);
        return this;
    }

    public FormPage enterDate(String dateValue) {
        driver.findElement(date).sendKeys(dateValue);
        return this;
    }

    public FormPage clickSubmitButton() {
        driver.findElement(btn_submit).click();
        return this;
    }
}
