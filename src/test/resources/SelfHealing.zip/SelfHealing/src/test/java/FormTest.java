import org.testng.annotations.Test;
import page.FormPage;

public class FormTest extends BaseTest{
    @Test
    public void testRegistrationForm(){
        FormPage formPage = new FormPage(driver);
        formPage.inputFirstName("FirstName");
        formPage.inputFirstName("LastName");
        formPage.inputjobTitle("SDET");
        formPage.selectEducationCollege();
        formPage.selectGenderMale();
        formPage.selectExperience("5-9");
        formPage.enterDate("10/01/2023");
        formPage.clickSubmitButton();

    }
}
